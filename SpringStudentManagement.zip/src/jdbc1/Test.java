package jdbc1;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApplicationContext con = new ClassPathXmlApplicationContext("jdbc1/App1.xml");
        StudentDao ob = (StudentDao) con.getBean("dao");
        char ch;
        System.out.println("****** Student Management System ******");
        do {
            System.out.println("1.Insert New Record \n2.Print All Records \n3.Update Records \n4.Delete Records");
            Student std = new Student();
            System.out.print("Enter your option: ");
            int n = sc.nextInt();
            switch(n) {
                case 1:
                    System.out.print("Enter Roll No: "); std.setRno(sc.nextInt());
                    System.out.print("Enter Name: "); std.setName(sc.next());
                    System.out.print("Enter Marks: "); std.setMarks(sc.nextDouble());
                    System.out.println(ob.save(std)); break;
                case 2: System.out.println(ob.getAllStudent()); break;
                case 3: System.out.println(ob.updateStudent(std)); break;
                case 4: System.out.println(ob.deleteStudent(std)); break;
                default: System.out.println("Invalid Option");
            }
            System.out.print("Continue? (y/n): ");
            ch = sc.next().charAt(0);
        } while(ch == 'y');
        System.out.println("Thank you!");
    }
}
