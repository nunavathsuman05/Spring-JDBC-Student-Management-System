package jdbc1;

import java.util.Scanner;
import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao 
{
    static Scanner sc = new Scanner(System.in);
    private JdbcTemplate template;

    public JdbcTemplate getTemplate() { return template; }
    public void setTemplate(JdbcTemplate template) { this.template = template; }

    public String save(Student st) {
        int c = template.update("insert into studnet values("+st.getRno()+",'"+st.getName()+"',"+st.getMarks()+")");
        return c > 0 ? "Inserted record successfully" : "Failed to insert record";
    }

    public String getAllStudent() {
        template.query("select * from studnet", (rs,rowNum)->{
            System.out.println(rs.getInt("rno")+" "+rs.getString("name")+" "+rs.getDouble("marks"));
            return null;
        });
        return "Retrieved all the data";
    }

    public String updateStudent(Student st) {
        String query = "update studnet set name = ? , marks= ? where rno =?";
        System.out.println("Enter roll no to update:");
        int rno = sc.nextInt();
        System.out.println("Enter updated Name:");
        String name = sc.next();
        System.out.println("Enter updated Marks:");
        double marks = sc.nextDouble();
        int c = template.update(query, name, marks, rno);
        return c > 0 ? "Record updated successfully" : "No record found";
    }

    public String deleteStudent(Student st) {
        String query = "delete from studnet where rno =?";
        System.out.println("Enter Roll No to delete:");
        int rno = sc.nextInt();
        int c = template.update(query, rno);
        return c > 0 ? "Record deleted successfully" : "No record found";
    }
}
